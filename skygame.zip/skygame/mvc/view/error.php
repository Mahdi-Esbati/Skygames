<br>
<div align="center">
	<span class="unselectable main-dialog" style="background-color: #f75e44;">
	404 NOT FOUND || متاسفانه صفحه مورد نظر شما پیدا نشد
		</span>
</div>
