<div align="center">
	<br>
	<div class="login-dialog">
<h1 class="iransansfnt" style="text-align:center ;color: #fff;text-shadow: 2px 2px #000;">ثبت نام کاربران</h1>

<form action="/user/register/" method="post">
<div class="mid">
	<p class="mainP">
		<input class="main_input" type="text" placeholder="نام کاربری" name="username">
		<br>
		<input class="main_input" type="text" placeholder="ایمیل" name="email">
		<br>
	</p>
	<p class="mainP">
		<input class="main_input" type="text" placeholder="نام" height="400px" width="500px" name="f_name">
		<br>
		<input class="main_input" type="text"  placeholder="نام خانوادگی" height="400px" width="500px" name="l_name">
	</p>
	<p class="mainP">
		<input class="main_input" type="text" placeholder="رمز عبور" height="400px" width="500px" name="password1">
		<br>
		<input class="main_input" type="text"  placeholder="تکرار رمز عبور" height="400px" width="500px" name="password2">
	</p>
	<p class="mainP">
		<button class="shadowed mainBtn" style="padding-left: 15px;padding-right: 15px" type="submit">ثبت نام</button>
	</p>
	</form>
	<a class="main-a unselectable" href="/user/login/">قبلا ثبت نام کرده اید؟</a>


</div>
</div>
</div>
</body>


