<br>
<div align="center">
	<span class="unselectable main-dialog" style="background-color: #1b9af7;">
	<?= $message ?>
		</span>
</div>

