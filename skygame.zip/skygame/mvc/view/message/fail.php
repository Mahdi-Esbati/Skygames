<br>
<div align="center">
	<span class="unselectable main-dialog" style="background-color: #f75e44;">
	<?= $message ?>
		</span>
</div>
