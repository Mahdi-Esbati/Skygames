<div align="center">
	<br>
	<h1>پست های سایت</h1>
	<br>

	<div class="shadowed post-container">
		<h4>انتخاب بر اساس موضوع : </h4>
		<select>
			<option>1</option>
			<option>1</option>
			<option>1</option>
		</select>
	</div>

	<div id="parent" class="shadowed post-container" align="right">
		<div id="image" class="image-container"><img class="main-img size100"></div>
		<div id="post" style="margin: 5px;color: #f1f1f1">
			<h2 id="Title">افتتاح بخش پست های سایت</h2>
			<span>
				افتتاح بخش پست های سایت ، از این به بعد ادمین ها میتوانند در سایت پست بگذارند و شروع به اضافه کردن مطالب به سایت بکنند
			</span>
			<hr class="main-hr">
				<button class="mainBtn">ادامه مطلب</button>
				<div id="tags" style="display: inline-block;float: left  ">
					<label class="tag-label" style="background-color: #7497a8">اخبار سایت</label>
				</div>
			</div>
	</div>


</div>
