<?php



define('_header2', "NOT DEFINED ERROR");
define('_head_imports', " 
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <title>SkyGame-Home</title>
        <meta name=\"Description\" content=\"mtmteam,mtm,mtmdesing,ام تی ام\">
        <meta name=\"Keywords\" content=\"mods,skygame,skyrim.totalwar,fallout,mountandblad,patch,dlc,دانلودمد,مود,اسکای گیم,توتال وار,\">

      
");
?>